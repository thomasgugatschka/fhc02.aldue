package A02_Queue;

public class Queue<T>
{
    private Node<T> first;
    
    private Node<T> last;
    /**
     * Das vorderste (=erste) Element aus der Queue entfernen und zur�ckliefern.
     * Existiert kein Element, wird eine Exception ausgel�st.
     * @throws QueueEmptyException 
     */
    public T dequeue() throws QueueEmptyException {
        if(first == null) {
            throw new QueueEmptyException();
        } else {
            T t = first.getData();
            Node<T> node = last;
            if(node.getNext() == null) {
                first = null;
                last = null;
            } else {
                while(node.getNext().hashCode() != first.hashCode()) {
                    node = node.getNext();
                }
                node.setNext(null);
                first = node;
            }
            return t;
        }
    }
    
    
    
    /**
     * �bergebenen Integer am Ende der Queue anh�ngen.
     * @param i Zahl
     */
    public void enqueue(T i) {
        Node<T> node = new Node<>(i);
        if(first == null) {
            first = node;
            last = node;
        } else {
           node.setNext(last);
           last = node;
        }

    }
    
    /**
     * Liefert die Anzahl der Elemente im Stack
     * @return
     */
    public int getCount() {
        int count = 1;
        if(last == null) {
            return 0;
        }
        Node n = last;
        while ((n = n.getNext()) != null) {
            count++;
        }
    	return count;
    }
}
